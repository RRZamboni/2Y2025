package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{
    // 1) Atributos
    EditText txtNome, txtFuncao, txtSalario;
    Button btnSalvarLimpar;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 2) 'Linkando' os elementos do layout com o Java   S2!!!
        txtNome = (EditText) findViewById(R.id.txtNome);
        txtFuncao = (EditText) findViewById(R.id.txtFuncao);
        txtSalario = (EditText) findViewById(R.id.txtSalario);
        btnSalvarLimpar = (Button) findViewById(R.id.btnSalvarLimpar);

        // 3) Evento do Botao
        btnSalvarLimpar.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                //Criando Variáveis para receber valores
                String nome = txtNome.getText().toString();
                String funcao = txtFuncao.getText().toString();

                //Convertendo de String(caractére) para Double(Real)
                double salario =  Double.parseDouble(
                                txtSalario.getText().toString());

                // Mostrando que funcionou
                String mensagem = "Nome: " + nome +
                                  "\n Função: " + funcao +
                                  "\n Salário: " + salario +
                                  "\n ACHO QUE TE AMO!!!";

                //!!!! TOAST !!!!
                Toast.makeText(MainActivity.this,
                                mensagem,
                                Toast.LENGTH_LONG).show();

            }
        });//
    }
}